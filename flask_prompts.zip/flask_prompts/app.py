from flask import Flask, render_template, request, redirect, url_for
from models import db, Prompt

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///prompts.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

@app.route('/', methods=['GET', 'POST'])
def index():
    category = request.args.get('category')
    if category:
        prompts = Prompt.query.filter_by(category=category).all()
    else:
        prompts = Prompt.query.all()
    return render_template('index.html', prompts=prompts)

@app.route('/admin')
def admin():
    prompts = Prompt.query.all()
    return render_template('admin.html', prompts=prompts)

@app.route('/admin/add', methods=['GET', 'POST'])
def add_prompt():
    if request.method == 'POST':
        prompt_text = request.form['prompt']
        category = request.form['category']
        if prompt_text and category:
            new_prompt = Prompt(text=prompt_text, category=category)
            db.session.add(new_prompt)
            db.session.commit()
        return redirect(url_for('admin'))

    return render_template('admin_add.html')  # Return the form for adding prompts

@app.route('/admin/delete/<int:id>', methods=['GET'])
def delete_prompt(id):
    prompt = Prompt.query.get_or_404(id)
    db.session.delete(prompt)
    db.session.commit()
    return redirect(url_for('admin'))

@app.route('/admin/update/<int:id>', methods=['GET', 'POST'])
def update_prompt(id):
    prompt = Prompt.query.get_or_404(id)
    if request.method == 'POST':
        prompt.text = request.form['prompt']
        prompt.category = request.form['category']  # Update category
        db.session.commit()
        return redirect(url_for('admin'))
    return render_template('update.html', prompt=prompt)

if __name__ == '__main__':
    app.run(debug=True)
